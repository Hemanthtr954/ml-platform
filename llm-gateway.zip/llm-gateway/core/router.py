"""
LLM Router — Smart multi-provider routing with cost, latency, and capability awareness.

Routing Strategy:
  1. Capability filter  — does the provider support the required features?
  2. Cost optimization  — prefer cheaper models when quality threshold is met
  3. Latency routing    — route to fastest available provider under load
  4. Circuit breaker    — skip unhealthy providers automatically
"""

from __future__ import annotations

import time
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from core.circuit_breaker import CircuitBreaker, CircuitState
from core.providers.base import BaseProvider, ProviderResponse
from observability.metrics import MetricsCollector

logger = logging.getLogger(__name__)


class RoutingStrategy(str, Enum):
    COST_OPTIMIZED = "cost_optimized"
    LATENCY_OPTIMIZED = "latency_optimized"
    QUALITY_OPTIMIZED = "quality_optimized"
    ROUND_ROBIN = "round_robin"


@dataclass
class RoutingConfig:
    strategy: RoutingStrategy = RoutingStrategy.COST_OPTIMIZED
    max_retries: int = 3
    fallback_enabled: bool = True
    timeout_seconds: float = 30.0
    required_capabilities: list[str] = field(default_factory=list)
    max_cost_per_1k_tokens: Optional[float] = None  # USD


@dataclass
class RouteResult:
    provider_name: str
    model: str
    response: ProviderResponse
    latency_ms: float
    cost_usd: float
    retries: int = 0
    fallback_used: bool = False


class LLMRouter:
    """
    Production-grade LLM router supporting multi-provider orchestration,
    intelligent fallback, and cost/latency optimization.
    """

    def __init__(
        self,
        providers: list[BaseProvider],
        config: RoutingConfig,
        metrics: MetricsCollector,
    ):
        self.providers = {p.name: p for p in providers}
        self.config = config
        self.metrics = metrics
        self.circuit_breakers: dict[str, CircuitBreaker] = {
            name: CircuitBreaker(name=name) for name in self.providers
        }
        self._round_robin_index = 0

    def route(self, messages: list[dict], **kwargs) -> RouteResult:
        """
        Route a request to the optimal provider based on the configured strategy.
        Falls back through the provider list on failures.
        """
        candidates = self._get_candidates()

        if not candidates:
            raise RuntimeError("No healthy providers available")

        last_error: Optional[Exception] = None

        for attempt, provider_name in enumerate(candidates):
            provider = self.providers[provider_name]
            cb = self.circuit_breakers[provider_name]

            if cb.state == CircuitState.OPEN:
                logger.warning(f"Skipping {provider_name}: circuit breaker OPEN")
                continue

            try:
                start = time.perf_counter()
                response = provider.complete(
                    messages=messages,
                    timeout=self.config.timeout_seconds,
                    **kwargs,
                )
                latency_ms = (time.perf_counter() - start) * 1000
                cost = self._estimate_cost(provider_name, response)

                cb.record_success()
                self.metrics.record_request(
                    provider=provider_name,
                    latency_ms=latency_ms,
                    cost_usd=cost,
                    success=True,
                )

                return RouteResult(
                    provider_name=provider_name,
                    model=provider.default_model,
                    response=response,
                    latency_ms=latency_ms,
                    cost_usd=cost,
                    retries=attempt,
                    fallback_used=attempt > 0,
                )

            except Exception as e:
                last_error = e
                cb.record_failure()
                self.metrics.record_request(
                    provider=provider_name,
                    latency_ms=0,
                    cost_usd=0,
                    success=False,
                    error=str(e),
                )
                logger.warning(
                    f"Provider {provider_name} failed (attempt {attempt + 1}): {e}"
                )

                if not self.config.fallback_enabled:
                    break

        raise RuntimeError(
            f"All providers exhausted after {len(candidates)} attempts. "
            f"Last error: {last_error}"
        )

    def _get_candidates(self) -> list[str]:
        """Return ordered list of provider names based on routing strategy."""
        available = [
            name
            for name, cb in self.circuit_breakers.items()
            if cb.state != CircuitState.OPEN
        ]

        if not available:
            return []

        if self.config.strategy == RoutingStrategy.COST_OPTIMIZED:
            return sorted(
                available,
                key=lambda n: self.providers[n].cost_per_1k_tokens,
            )

        if self.config.strategy == RoutingStrategy.LATENCY_OPTIMIZED:
            return sorted(
                available,
                key=lambda n: self.metrics.avg_latency(n),
            )

        if self.config.strategy == RoutingStrategy.ROUND_ROBIN:
            rotated = available[self._round_robin_index:] + available[:self._round_robin_index]
            self._round_robin_index = (self._round_robin_index + 1) % len(available)
            return rotated

        # Default: quality_optimized — use provider priority order
        return available

    def _estimate_cost(self, provider_name: str, response: ProviderResponse) -> float:
        provider = self.providers[provider_name]
        total_tokens = response.usage.get("total_tokens", 0)
        return (total_tokens / 1000) * provider.cost_per_1k_tokens

    def health_summary(self) -> dict:
        return {
            name: {
                "state": cb.state.value,
                "failure_count": cb.failure_count,
                "avg_latency_ms": round(self.metrics.avg_latency(name), 2),
            }
            for name, cb in self.circuit_breakers.items()
        }
