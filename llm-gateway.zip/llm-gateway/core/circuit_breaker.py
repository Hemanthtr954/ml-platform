"""
Circuit Breaker — Prevents cascading failures across LLM providers.

States:
  CLOSED   → normal operation, requests flow through
  OPEN     → provider is unhealthy, requests are blocked
  HALF_OPEN → probe state, one request allowed to test recovery
"""

from __future__ import annotations

import time
import logging
import threading
from enum import Enum

logger = logging.getLogger(__name__)


class CircuitState(str, Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreaker:
    """
    Thread-safe circuit breaker with configurable thresholds and recovery window.
    """

    def __init__(
        self,
        name: str,
        failure_threshold: int = 5,
        recovery_timeout_seconds: float = 60.0,
        half_open_max_calls: int = 1,
    ):
        self.name = name
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout_seconds
        self.half_open_max_calls = half_open_max_calls

        self._state = CircuitState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self._last_failure_time: float = 0
        self._half_open_calls = 0
        self._lock = threading.Lock()

    @property
    def state(self) -> CircuitState:
        with self._lock:
            if self._state == CircuitState.OPEN:
                if time.time() - self._last_failure_time >= self.recovery_timeout:
                    logger.info(f"[{self.name}] Circuit transitioning OPEN → HALF_OPEN")
                    self._state = CircuitState.HALF_OPEN
                    self._half_open_calls = 0
            return self._state

    def record_success(self) -> None:
        with self._lock:
            self.success_count += 1
            if self._state == CircuitState.HALF_OPEN:
                self._half_open_calls += 1
                if self._half_open_calls >= self.half_open_max_calls:
                    logger.info(f"[{self.name}] Circuit CLOSED — provider recovered")
                    self._state = CircuitState.CLOSED
                    self.failure_count = 0
            elif self._state == CircuitState.CLOSED:
                # Reset failure count on success to avoid false trips
                self.failure_count = max(0, self.failure_count - 1)

    def record_failure(self) -> None:
        with self._lock:
            self.failure_count += 1
            self._last_failure_time = time.time()

            if self._state == CircuitState.HALF_OPEN:
                logger.warning(f"[{self.name}] HALF_OPEN probe failed → reopening circuit")
                self._state = CircuitState.OPEN
            elif self.failure_count >= self.failure_threshold:
                logger.error(
                    f"[{self.name}] Failure threshold reached ({self.failure_count}) → OPEN"
                )
                self._state = CircuitState.OPEN

    def reset(self) -> None:
        """Manually reset circuit — useful for admin operations."""
        with self._lock:
            self._state = CircuitState.CLOSED
            self.failure_count = 0
            self._half_open_calls = 0
            logger.info(f"[{self.name}] Circuit manually reset to CLOSED")
