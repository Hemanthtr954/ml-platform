"""
Anthropic Provider Adapter — Claude models via the Anthropic SDK.
Handles message format translation (OpenAI-style → Anthropic-style).
"""

from __future__ import annotations

import logging
from typing import AsyncIterator

import anthropic

from core.providers.base import BaseProvider, ProviderResponse, StreamChunk

logger = logging.getLogger(__name__)


class AnthropicProvider(BaseProvider):
    name = "anthropic"
    default_model = "claude-3-5-sonnet-20241022"
    cost_per_1k_tokens = 0.004  # blended estimate
    capabilities = ["function_calling", "vision", "streaming", "long_context"]

    def __init__(self, api_key: str, model: str = "claude-3-5-sonnet-20241022"):
        self.default_model = model
        self._client = anthropic.Anthropic(api_key=api_key)
        self._async_client = anthropic.AsyncAnthropic(api_key=api_key)

    def _convert_messages(self, messages: list[dict]) -> tuple[str | None, list[dict]]:
        """
        Convert OpenAI-format messages to Anthropic format.
        Extracts system prompt and returns (system, user_messages).
        """
        system = None
        converted = []
        for msg in messages:
            role = msg["role"]
            if role == "system":
                system = msg["content"]
            elif role in ("user", "assistant"):
                converted.append({"role": role, "content": msg["content"]})
        return system, converted

    def complete(
        self,
        messages: list[dict],
        timeout: float = 30.0,
        **kwargs,
    ) -> ProviderResponse:
        system, converted_messages = self._convert_messages(messages)

        try:
            params = dict(
                model=kwargs.pop("model", self.default_model),
                max_tokens=kwargs.pop("max_tokens", 4096),
                messages=converted_messages,
                **kwargs,
            )
            if system:
                params["system"] = system

            response = self._client.messages.create(**params)
            content = response.content[0].text if response.content else ""

            return ProviderResponse(
                content=content,
                model=response.model,
                usage={
                    "prompt_tokens": response.usage.input_tokens,
                    "completion_tokens": response.usage.output_tokens,
                    "total_tokens": response.usage.input_tokens + response.usage.output_tokens,
                },
                finish_reason=response.stop_reason,
                raw=response.model_dump(),
            )
        except anthropic.APITimeoutError as e:
            logger.error(f"[Anthropic] Timeout: {e}")
            raise
        except anthropic.RateLimitError as e:
            logger.warning(f"[Anthropic] Rate limited: {e}")
            raise
        except anthropic.APIStatusError as e:
            logger.error(f"[Anthropic] API error {e.status_code}: {e.message}")
            raise

    async def stream(
        self,
        messages: list[dict],
        timeout: float = 30.0,
        **kwargs,
    ) -> AsyncIterator[StreamChunk]:
        system, converted_messages = self._convert_messages(messages)
        params = dict(
            model=kwargs.pop("model", self.default_model),
            max_tokens=kwargs.pop("max_tokens", 4096),
            messages=converted_messages,
            **kwargs,
        )
        if system:
            params["system"] = system

        async with self._async_client.messages.stream(**params) as stream:
            async for text in stream.text_stream:
                yield StreamChunk(delta=text)

    def health_check(self) -> bool:
        try:
            # Minimal probe — list models or send tiny request
            self._client.models.list()
            return True
        except Exception as e:
            logger.warning(f"[Anthropic] Health check failed: {e}")
            return False
