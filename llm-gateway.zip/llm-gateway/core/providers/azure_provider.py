"""
Azure OpenAI Provider Adapter — Enterprise Azure OpenAI with deployment-based routing.
Used at ServiceNow-scale where Azure provides compliance, SLA, and regional routing.
"""

from __future__ import annotations

import logging
from typing import AsyncIterator

import openai
from openai import AzureOpenAI, AsyncAzureOpenAI

from core.providers.base import BaseProvider, ProviderResponse, StreamChunk

logger = logging.getLogger(__name__)


class AzureOpenAIProvider(BaseProvider):
    name = "azure_openai"
    cost_per_1k_tokens = 0.005
    capabilities = ["function_calling", "vision", "json_mode", "streaming"]

    def __init__(
        self,
        api_key: str,
        azure_endpoint: str,
        deployment_name: str,
        api_version: str = "2024-08-01-preview",
    ):
        self.default_model = deployment_name
        self._deployment = deployment_name
        self._client = AzureOpenAI(
            api_key=api_key,
            azure_endpoint=azure_endpoint,
            api_version=api_version,
        )
        self._async_client = AsyncAzureOpenAI(
            api_key=api_key,
            azure_endpoint=azure_endpoint,
            api_version=api_version,
        )

    def complete(
        self,
        messages: list[dict],
        timeout: float = 30.0,
        **kwargs,
    ) -> ProviderResponse:
        try:
            response = self._client.chat.completions.create(
                model=self._deployment,  # Azure uses deployment name as model
                messages=messages,
                timeout=timeout,
                **kwargs,
            )
            choice = response.choices[0]
            return ProviderResponse(
                content=choice.message.content or "",
                model=response.model,
                usage={
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens,
                },
                finish_reason=choice.finish_reason,
                raw=response.model_dump(),
            )
        except openai.APITimeoutError as e:
            logger.error(f"[Azure] Timeout after {timeout}s: {e}")
            raise
        except openai.RateLimitError as e:
            logger.warning(f"[Azure] Rate limited — consider PTU deployment: {e}")
            raise
        except openai.APIStatusError as e:
            logger.error(f"[Azure] API error {e.status_code}: {e.message}")
            raise

    async def stream(
        self,
        messages: list[dict],
        timeout: float = 30.0,
        **kwargs,
    ) -> AsyncIterator[StreamChunk]:
        async with self._async_client.chat.completions.stream(
            model=self._deployment,
            messages=messages,
            timeout=timeout,
            **kwargs,
        ) as stream:
            async for event in stream:
                if event.choices:
                    delta = event.choices[0].delta.content or ""
                    finish = event.choices[0].finish_reason
                    yield StreamChunk(delta=delta, finish_reason=finish)

    def health_check(self) -> bool:
        try:
            self._client.models.list()
            return True
        except Exception as e:
            logger.warning(f"[Azure] Health check failed: {e}")
            return False
