"""
Base Provider — Abstract interface all LLM providers must implement.
Enforces a consistent contract across OpenAI, Anthropic, Azure, etc.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import AsyncIterator, Optional


@dataclass
class ProviderResponse:
    content: str
    model: str
    usage: dict = field(default_factory=dict)  # prompt_tokens, completion_tokens, total_tokens
    raw: dict = field(default_factory=dict)    # original provider response
    finish_reason: Optional[str] = None


@dataclass
class StreamChunk:
    delta: str
    finish_reason: Optional[str] = None
    model: Optional[str] = None


class BaseProvider(ABC):
    """
    Abstract base class for all LLM providers.
    Each provider adapter must implement complete() and stream().
    """

    name: str
    default_model: str
    cost_per_1k_tokens: float  # USD, approximate blended input+output cost

    @abstractmethod
    def complete(
        self,
        messages: list[dict],
        timeout: float = 30.0,
        **kwargs,
    ) -> ProviderResponse:
        """Synchronous completion. Raises on error."""
        ...

    @abstractmethod
    async def stream(
        self,
        messages: list[dict],
        timeout: float = 30.0,
        **kwargs,
    ) -> AsyncIterator[StreamChunk]:
        """Async streaming completion."""
        ...

    @abstractmethod
    def health_check(self) -> bool:
        """Returns True if the provider is reachable."""
        ...

    def supports_capability(self, capability: str) -> bool:
        """Override to declare provider capabilities: vision, function_calling, etc."""
        return capability in getattr(self, "capabilities", [])
