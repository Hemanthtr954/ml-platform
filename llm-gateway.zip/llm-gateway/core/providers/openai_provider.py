"""
OpenAI Provider Adapter — Wraps the OpenAI SDK with retry logic,
timeout enforcement, structured error handling, and streaming support.
"""

from __future__ import annotations

import logging
from typing import AsyncIterator

import openai
from openai import OpenAI, AsyncOpenAI

from core.providers.base import BaseProvider, ProviderResponse, StreamChunk

logger = logging.getLogger(__name__)


class OpenAIProvider(BaseProvider):
    name = "openai"
    default_model = "gpt-4o"
    cost_per_1k_tokens = 0.005  # blended gpt-4o input+output estimate
    capabilities = ["function_calling", "vision", "json_mode", "streaming"]

    def __init__(self, api_key: str, model: str = "gpt-4o", org_id: str | None = None):
        self.default_model = model
        self._client = OpenAI(api_key=api_key, organization=org_id)
        self._async_client = AsyncOpenAI(api_key=api_key, organization=org_id)

    def complete(
        self,
        messages: list[dict],
        timeout: float = 30.0,
        **kwargs,
    ) -> ProviderResponse:
        try:
            response = self._client.chat.completions.create(
                model=kwargs.pop("model", self.default_model),
                messages=messages,
                timeout=timeout,
                **kwargs,
            )
            choice = response.choices[0]
            return ProviderResponse(
                content=choice.message.content or "",
                model=response.model,
                usage={
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens,
                },
                finish_reason=choice.finish_reason,
                raw=response.model_dump(),
            )
        except openai.APITimeoutError as e:
            logger.error(f"[OpenAI] Timeout after {timeout}s: {e}")
            raise
        except openai.RateLimitError as e:
            logger.warning(f"[OpenAI] Rate limited: {e}")
            raise
        except openai.APIStatusError as e:
            logger.error(f"[OpenAI] API error {e.status_code}: {e.message}")
            raise

    async def stream(
        self,
        messages: list[dict],
        timeout: float = 30.0,
        **kwargs,
    ) -> AsyncIterator[StreamChunk]:
        async with self._async_client.chat.completions.stream(
            model=kwargs.pop("model", self.default_model),
            messages=messages,
            timeout=timeout,
            **kwargs,
        ) as stream:
            async for event in stream:
                if event.choices:
                    delta = event.choices[0].delta.content or ""
                    finish = event.choices[0].finish_reason
                    yield StreamChunk(delta=delta, finish_reason=finish, model=event.model)

    def health_check(self) -> bool:
        try:
            self._client.models.list()
            return True
        except Exception as e:
            logger.warning(f"[OpenAI] Health check failed: {e}")
            return False
