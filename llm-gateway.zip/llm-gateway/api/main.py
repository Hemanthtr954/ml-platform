"""
LLM Gateway API — FastAPI application exposing the gateway over HTTP.

Endpoints:
  POST /v1/chat/completions   — OpenAI-compatible completion endpoint
  POST /v1/chat/stream        — SSE streaming endpoint
  GET  /health                — Health check with provider status
  GET  /metrics               — Prometheus metrics export
  GET  /metrics/json          — JSON metrics for dashboards
  GET  /admin/circuit-breakers — Circuit breaker states
  POST /admin/circuit-breakers/{provider}/reset — Manual CB reset
"""

from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from typing import AsyncIterator, Optional

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, PlainTextResponse
from pydantic import BaseModel, Field

from core.circuit_breaker import CircuitBreaker
from core.providers.anthropic_provider import AnthropicProvider
from core.providers.azure_provider import AzureOpenAIProvider
from core.providers.openai_provider import OpenAIProvider
from core.router import LLMRouter, RoutingConfig, RoutingStrategy
from observability.metrics import MetricsCollector
from observability.token_tracker import BudgetConfig, TokenBudgetManager
from prompt.injection_guard import PromptInjectionGuard, ThreatLevel
from prompt.template_manager import TemplateManager

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)

# ── Globals ───────────────────────────────────────────────────────────────────

metrics = MetricsCollector()
injection_guard = PromptInjectionGuard(block_on_detection=True)
budget_manager = TokenBudgetManager(BudgetConfig())
template_manager = TemplateManager()
router: Optional[LLMRouter] = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global router
    providers = []

    if key := os.getenv("OPENAI_API_KEY"):
        providers.append(OpenAIProvider(api_key=key))
        logger.info("OpenAI provider registered")

    if key := os.getenv("ANTHROPIC_API_KEY"):
        providers.append(AnthropicProvider(api_key=key))
        logger.info("Anthropic provider registered")

    if (
        (key := os.getenv("AZURE_OPENAI_API_KEY"))
        and (endpoint := os.getenv("AZURE_OPENAI_ENDPOINT"))
        and (deployment := os.getenv("AZURE_OPENAI_DEPLOYMENT"))
    ):
        providers.append(
            AzureOpenAIProvider(
                api_key=key,
                azure_endpoint=endpoint,
                deployment_name=deployment,
            )
        )
        logger.info("Azure OpenAI provider registered")

    if not providers:
        logger.warning("No providers configured — set API key env vars")

    strategy = RoutingStrategy(
        os.getenv("ROUTING_STRATEGY", RoutingStrategy.COST_OPTIMIZED)
    )
    config = RoutingConfig(strategy=strategy)
    router = LLMRouter(providers=providers, config=config, metrics=metrics)
    logger.info(f"LLM Gateway started with {len(providers)} providers | strategy={strategy}")
    yield
    logger.info("LLM Gateway shutting down")


app = FastAPI(
    title="LLM Gateway",
    description="Multi-provider LLM orchestration with circuit breakers, cost optimization, and safety guardrails",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Request / Response Models ─────────────────────────────────────────────────

class Message(BaseModel):
    role: str
    content: str


class CompletionRequest(BaseModel):
    messages: list[Message]
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    max_tokens: int = Field(default=1000, ge=1, le=8000)
    stream: bool = False
    routing_strategy: Optional[str] = None
    template_name: Optional[str] = None
    template_version: Optional[str] = None
    template_variables: Optional[dict] = None


class CompletionResponse(BaseModel):
    content: str
    provider: str
    model: str
    latency_ms: float
    cost_usd: float
    fallback_used: bool
    cached: bool = False


# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.post("/v1/chat/completions", response_model=CompletionResponse)
async def chat_completions(request: CompletionRequest):
    if not router:
        raise HTTPException(503, "Gateway not initialized")

    messages = [m.model_dump() for m in request.messages]

    # 1. Template rendering (if requested)
    if request.template_name:
        template = template_manager.get(
            request.template_name, request.template_version
        )
        messages = template.render(request.template_variables or {})

    # 2. Injection scan
    scan_results = injection_guard.scan_messages(messages)
    for result in scan_results:
        if result.threat_level == ThreatLevel.BLOCKED:
            raise HTTPException(400, "Request blocked: prompt injection detected")

    # 3. Cache check
    cached_response = budget_manager.check_cache(messages)
    if cached_response:
        return CompletionResponse(
            content=cached_response,
            provider="cache",
            model="cache",
            latency_ms=0,
            cost_usd=0,
            fallback_used=False,
            cached=True,
        )

    # 4. Token budget enforcement
    messages = budget_manager.enforce_budget(messages)

    # 5. Route and complete
    try:
        result = router.route(
            messages=messages,
            temperature=request.temperature,
            max_tokens=request.max_tokens,
        )
    except RuntimeError as e:
        raise HTTPException(503, f"All providers unavailable: {e}")

    # 6. Cache successful response
    budget_manager.store_cache(messages, result.response.content)

    return CompletionResponse(
        content=result.response.content,
        provider=result.provider_name,
        model=result.model,
        latency_ms=round(result.latency_ms, 2),
        cost_usd=round(result.cost_usd, 6),
        fallback_used=result.fallback_used,
    )


@app.get("/health")
async def health():
    if not router:
        return {"status": "starting", "providers": {}}
    return {
        "status": "healthy",
        "providers": router.health_summary(),
    }


@app.get("/metrics", response_class=PlainTextResponse)
async def prometheus_metrics():
    return metrics.prometheus_export()


@app.get("/metrics/json")
async def json_metrics():
    return metrics.get_all_stats()


@app.get("/admin/circuit-breakers")
async def circuit_breaker_status():
    if not router:
        raise HTTPException(503, "Gateway not initialized")
    return {
        name: {
            "state": cb.state.value,
            "failure_count": cb.failure_count,
        }
        for name, cb in router.circuit_breakers.items()
    }


@app.post("/admin/circuit-breakers/{provider}/reset")
async def reset_circuit_breaker(provider: str):
    if not router:
        raise HTTPException(503, "Gateway not initialized")
    if provider not in router.circuit_breakers:
        raise HTTPException(404, f"Provider '{provider}' not found")
    router.circuit_breakers[provider].reset()
    return {"status": "reset", "provider": provider}


@app.get("/templates")
async def list_templates():
    return template_manager.list_templates()
