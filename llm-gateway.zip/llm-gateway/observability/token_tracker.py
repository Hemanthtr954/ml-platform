"""
Token Budget Manager — Enforces token budgets and applies cost-optimization strategies.

Strategies implemented:
  1. Hard token limits — truncate inputs that exceed budget
  2. Adaptive model selection — downgrade model tier for simple tasks
  3. Response caching — skip inference for repeated prompts
  4. Context compression — summarize long conversation history
"""

from __future__ import annotations

import hashlib
import logging
import time
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)

# Approximate token counts (rule of thumb: 1 token ≈ 4 chars)
CHARS_PER_TOKEN = 4


def estimate_tokens(text: str) -> int:
    return max(1, len(text) // CHARS_PER_TOKEN)


def estimate_messages_tokens(messages: list[dict]) -> int:
    total = 0
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            total += estimate_tokens(content)
        total += 4  # per-message overhead
    return total + 3  # reply priming


@dataclass
class BudgetConfig:
    max_input_tokens: int = 8000
    max_output_tokens: int = 2000
    enable_caching: bool = True
    cache_ttl_seconds: int = 300
    compress_at_token_count: int = 6000


class TokenBudgetManager:
    """
    Manages token budgets and applies cost-optimization strategies before routing.
    """

    def __init__(self, config: BudgetConfig):
        self.config = config
        self._cache: dict[str, tuple[str, float]] = {}  # hash → (response, timestamp)

    def check_cache(self, messages: list[dict]) -> Optional[str]:
        if not self.config.enable_caching:
            return None

        key = self._cache_key(messages)
        if key in self._cache:
            response, ts = self._cache[key]
            if time.time() - ts < self.config.cache_ttl_seconds:
                logger.info("[TokenBudget] Cache hit")
                return response
            else:
                del self._cache[key]
        return None

    def store_cache(self, messages: list[dict], response: str) -> None:
        if not self.config.enable_caching:
            return
        key = self._cache_key(messages)
        self._cache[key] = (response, time.time())

    def enforce_budget(self, messages: list[dict]) -> list[dict]:
        """
        Truncate or compress messages to fit within token budget.
        Preserves system prompt and most recent user message.
        """
        estimated = estimate_messages_tokens(messages)

        if estimated <= self.config.max_input_tokens:
            return messages

        logger.warning(
            f"[TokenBudget] Estimated {estimated} tokens exceeds budget "
            f"{self.config.max_input_tokens} — compressing"
        )

        return self._compress_messages(messages)

    def _compress_messages(self, messages: list[dict]) -> list[dict]:
        """
        Compression strategy:
          1. Always keep system prompt
          2. Always keep last user message
          3. Truncate middle history until within budget
        """
        system_msgs = [m for m in messages if m["role"] == "system"]
        non_system = [m for m in messages if m["role"] != "system"]

        if not non_system:
            return system_msgs

        # Always keep last message
        last_msg = non_system[-1]
        history = non_system[:-1]

        compressed = system_msgs.copy()
        budget_remaining = self.config.max_input_tokens - estimate_messages_tokens(
            system_msgs + [last_msg]
        )

        # Add history from most recent backwards until budget exhausted
        for msg in reversed(history):
            msg_tokens = estimate_tokens(msg.get("content", ""))
            if budget_remaining - msg_tokens > 0:
                compressed.insert(len(system_msgs), msg)
                budget_remaining -= msg_tokens
            else:
                break

        compressed.append(last_msg)
        logger.info(
            f"[TokenBudget] Compressed {len(messages)} → {len(compressed)} messages"
        )
        return compressed

    def _cache_key(self, messages: list[dict]) -> str:
        content = str([(m["role"], m.get("content", "")) for m in messages])
        return hashlib.sha256(content.encode()).hexdigest()

    def get_cache_stats(self) -> dict:
        now = time.time()
        active = sum(
            1 for _, ts in self._cache.values()
            if now - ts < self.config.cache_ttl_seconds
        )
        return {"total_entries": len(self._cache), "active_entries": active}
