"""
Metrics Collector — Structured observability for LLM gateway.

Tracks per-provider:
  - Request counts (success / failure)
  - Latency distribution (p50, p95, p99)
  - Token usage and estimated cost
  - Error rates by type

Designed to export to Prometheus / CloudWatch / Datadog.
"""

from __future__ import annotations

import logging
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

# Rolling window for latency calculations (last N requests)
LATENCY_WINDOW = 1000


@dataclass
class ProviderStats:
    total_requests: int = 0
    success_count: int = 0
    failure_count: int = 0
    total_tokens: int = 0
    total_cost_usd: float = 0.0
    error_counts: dict = field(default_factory=lambda: defaultdict(int))
    latencies_ms: deque = field(default_factory=lambda: deque(maxlen=LATENCY_WINDOW))

    @property
    def error_rate(self) -> float:
        if self.total_requests == 0:
            return 0.0
        return self.failure_count / self.total_requests

    @property
    def p50_latency(self) -> float:
        return self._percentile(0.50)

    @property
    def p95_latency(self) -> float:
        return self._percentile(0.95)

    @property
    def p99_latency(self) -> float:
        return self._percentile(0.99)

    def _percentile(self, p: float) -> float:
        if not self.latencies_ms:
            return 0.0
        sorted_latencies = sorted(self.latencies_ms)
        idx = int(len(sorted_latencies) * p)
        return sorted_latencies[min(idx, len(sorted_latencies) - 1)]


class MetricsCollector:
    """
    Thread-safe in-process metrics store.
    For production, flush to Prometheus push gateway or CloudWatch.
    """

    def __init__(self):
        self._stats: dict[str, ProviderStats] = defaultdict(ProviderStats)
        self._lock = threading.Lock()
        self._gateway_stats = {
            "total_requests": 0,
            "start_time": time.time(),
        }

    def record_request(
        self,
        provider: str,
        latency_ms: float,
        cost_usd: float,
        success: bool,
        tokens: int = 0,
        error: Optional[str] = None,
    ) -> None:
        with self._lock:
            stats = self._stats[provider]
            stats.total_requests += 1
            self._gateway_stats["total_requests"] += 1

            if success:
                stats.success_count += 1
                stats.latencies_ms.append(latency_ms)
                stats.total_tokens += tokens
                stats.total_cost_usd += cost_usd
            else:
                stats.failure_count += 1
                if error:
                    error_type = error.split(":")[0][:50]
                    stats.error_counts[error_type] += 1

    def avg_latency(self, provider: str) -> float:
        with self._lock:
            stats = self._stats.get(provider)
            if not stats or not stats.latencies_ms:
                return 0.0
            return sum(stats.latencies_ms) / len(stats.latencies_ms)

    def get_provider_stats(self, provider: str) -> dict:
        with self._lock:
            stats = self._stats.get(provider, ProviderStats())
            return {
                "total_requests": stats.total_requests,
                "success_count": stats.success_count,
                "failure_count": stats.failure_count,
                "error_rate": round(stats.error_rate, 4),
                "total_tokens": stats.total_tokens,
                "total_cost_usd": round(stats.total_cost_usd, 6),
                "latency_p50_ms": round(stats.p50_latency, 2),
                "latency_p95_ms": round(stats.p95_latency, 2),
                "latency_p99_ms": round(stats.p99_latency, 2),
                "top_errors": dict(list(stats.error_counts.items())[:5]),
            }

    def get_all_stats(self) -> dict:
        with self._lock:
            uptime = time.time() - self._gateway_stats["start_time"]
            return {
                "gateway": {
                    "total_requests": self._gateway_stats["total_requests"],
                    "uptime_seconds": round(uptime, 1),
                },
                "providers": {
                    name: self.get_provider_stats(name)
                    for name in self._stats
                },
            }

    def prometheus_export(self) -> str:
        """Export metrics in Prometheus text format."""
        lines = []
        with self._lock:
            for provider, stats in self._stats.items():
                prefix = f'llm_gateway_provider{{provider="{provider}"}}'
                lines += [
                    f'llm_gateway_requests_total{{provider="{provider}",status="success"}} {stats.success_count}',
                    f'llm_gateway_requests_total{{provider="{provider}",status="failure"}} {stats.failure_count}',
                    f'llm_gateway_cost_usd_total{{provider="{provider}"}} {stats.total_cost_usd:.6f}',
                    f'llm_gateway_tokens_total{{provider="{provider}"}} {stats.total_tokens}',
                    f'llm_gateway_latency_p95_ms{{provider="{provider}"}} {stats.p95_latency:.2f}',
                ]
        return "\n".join(lines)
