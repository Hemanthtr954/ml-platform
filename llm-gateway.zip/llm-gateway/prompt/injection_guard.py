"""
Prompt Security — Injection detection and mitigation.

Defends against:
  - Direct prompt injection (user overriding system instructions)
  - Indirect injection (malicious content in retrieved context)
  - Jailbreak patterns (role-play, hypothetical, DAN-style attacks)
"""

from __future__ import annotations

import re
import logging
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class ThreatLevel(str, Enum):
    SAFE = "safe"
    SUSPICIOUS = "suspicious"
    BLOCKED = "blocked"


@dataclass
class InjectionScanResult:
    threat_level: ThreatLevel
    matched_patterns: list[str]
    sanitized_input: str
    original_input: str


# Patterns ordered by severity
INJECTION_PATTERNS = [
    # Instruction override attempts
    (r"ignore (all |previous |above |prior )?(instructions?|prompts?|rules?|context)", "instruction_override"),
    (r"disregard (your |all |previous )?(instructions?|training|guidelines?)", "instruction_override"),
    (r"forget (everything|what you were told|your instructions)", "instruction_override"),
    # Role/persona hijacking
    (r"\byou are now\b.{0,50}(assistant|ai|bot|gpt|claude)", "persona_hijacking"),
    (r"\bact as\b.{0,50}(unrestricted|jailbreak|dan\b)", "persona_hijacking"),
    (r"\bpretend (you are|to be)\b.{0,50}(no (restrictions?|rules?|limits?))", "persona_hijacking"),
    # System prompt extraction
    (r"(reveal|show|print|display|output).{0,30}(system prompt|instructions?|rules?)", "prompt_extraction"),
    (r"what (are|were) your (instructions?|system prompt|rules?)", "prompt_extraction"),
    # Boundary escape
    (r"</?(system|user|assistant|prompt|instruction)>", "boundary_escape"),
    (r"\[INST\]|\[/INST\]|<<SYS>>|<</SYS>>", "boundary_escape"),
    # DAN / jailbreak
    (r"\bDAN\b|\bjailbreak\b", "jailbreak_attempt"),
    (r"developer mode|god mode|unrestricted mode", "jailbreak_attempt"),
]

COMPILED_PATTERNS = [
    (re.compile(pattern, re.IGNORECASE), label)
    for pattern, label in INJECTION_PATTERNS
]

# Patterns that are always blocked (no sanitization possible)
BLOCK_PATTERNS = {"instruction_override", "persona_hijacking", "jailbreak_attempt"}


class PromptInjectionGuard:
    """
    Stateless scanner for prompt injection attempts.
    Can run in DETECT-only or BLOCK mode.
    """

    def __init__(self, block_on_detection: bool = True):
        self.block_on_detection = block_on_detection

    def scan(self, text: str) -> InjectionScanResult:
        matched = []

        for pattern, label in COMPILED_PATTERNS:
            if pattern.search(text):
                matched.append(label)
                logger.warning(f"[InjectionGuard] Pattern matched: {label}")

        if not matched:
            return InjectionScanResult(
                threat_level=ThreatLevel.SAFE,
                matched_patterns=[],
                sanitized_input=text,
                original_input=text,
            )

        has_block_pattern = any(m in BLOCK_PATTERNS for m in matched)

        if has_block_pattern and self.block_on_detection:
            return InjectionScanResult(
                threat_level=ThreatLevel.BLOCKED,
                matched_patterns=matched,
                sanitized_input="",
                original_input=text,
            )

        # Sanitize: strip matched segments
        sanitized = self._sanitize(text)
        return InjectionScanResult(
            threat_level=ThreatLevel.SUSPICIOUS,
            matched_patterns=matched,
            sanitized_input=sanitized,
            original_input=text,
        )

    def scan_messages(self, messages: list[dict]) -> list[InjectionScanResult]:
        results = []
        for msg in messages:
            if msg.get("role") == "user":
                result = self.scan(msg.get("content", ""))
                results.append(result)
        return results

    def _sanitize(self, text: str) -> str:
        sanitized = text
        for pattern, _ in COMPILED_PATTERNS:
            sanitized = pattern.sub("[REDACTED]", sanitized)
        return sanitized
