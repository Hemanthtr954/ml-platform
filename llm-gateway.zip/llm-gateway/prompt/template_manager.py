"""
Prompt Template Manager — Versioned, typed prompt templates with variable substitution.

Features:
  - Version-controlled templates stored in YAML
  - Jinja2-based variable interpolation
  - Template validation at load time
  - A/B variant support for prompt experiments
"""

from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import yaml
from jinja2 import Environment, StrictUndefined, TemplateError

logger = logging.getLogger(__name__)


@dataclass
class PromptTemplate:
    name: str
    version: str
    system_prompt: str
    user_template: str
    variables: list[str] = field(default_factory=list)
    description: str = ""
    tags: list[str] = field(default_factory=list)

    @property
    def template_hash(self) -> str:
        """Stable hash for tracking which template version produced a response."""
        content = f"{self.name}:{self.version}:{self.system_prompt}:{self.user_template}"
        return hashlib.sha256(content.encode()).hexdigest()[:12]

    def render(self, variables: dict[str, Any]) -> list[dict]:
        """
        Render template into OpenAI-compatible message format.
        Raises TemplateError if required variables are missing.
        """
        env = Environment(undefined=StrictUndefined)
        try:
            rendered_user = env.from_string(self.user_template).render(**variables)
            rendered_system = env.from_string(self.system_prompt).render(**variables)
        except Exception as e:
            raise TemplateError(f"Template render failed for '{self.name}': {e}") from e

        messages = []
        if rendered_system.strip():
            messages.append({"role": "system", "content": rendered_system})
        messages.append({"role": "user", "content": rendered_user})
        return messages


class TemplateManager:
    """
    Registry for loading and retrieving versioned prompt templates.
    Templates are loaded from YAML files in a templates directory.
    """

    def __init__(self, templates_dir: str = "prompt/templates"):
        self._templates: dict[str, dict[str, PromptTemplate]] = {}  # name → version → template
        self._templates_dir = Path(templates_dir)
        self._load_all()

    def _load_all(self) -> None:
        if not self._templates_dir.exists():
            logger.warning(f"Templates directory not found: {self._templates_dir}")
            return

        for yaml_file in self._templates_dir.glob("*.yaml"):
            try:
                self._load_file(yaml_file)
            except Exception as e:
                logger.error(f"Failed to load template {yaml_file}: {e}")

    def _load_file(self, path: Path) -> None:
        with open(path) as f:
            data = yaml.safe_load(f)

        template = PromptTemplate(
            name=data["name"],
            version=data["version"],
            system_prompt=data.get("system_prompt", ""),
            user_template=data["user_template"],
            variables=data.get("variables", []),
            description=data.get("description", ""),
            tags=data.get("tags", []),
        )

        if template.name not in self._templates:
            self._templates[template.name] = {}

        self._templates[template.name][template.version] = template
        logger.debug(f"Loaded template: {template.name} v{template.version}")

    def get(self, name: str, version: Optional[str] = None) -> PromptTemplate:
        """
        Retrieve a template by name and optional version.
        If version is omitted, returns the latest version.
        """
        if name not in self._templates:
            raise KeyError(f"Template '{name}' not found")

        versions = self._templates[name]

        if version:
            if version not in versions:
                raise KeyError(f"Template '{name}' version '{version}' not found")
            return versions[version]

        # Return latest version (lexicographic sort works for semver)
        latest = sorted(versions.keys())[-1]
        return versions[latest]

    def register(self, template: PromptTemplate) -> None:
        """Programmatically register a template (useful for testing)."""
        if template.name not in self._templates:
            self._templates[template.name] = {}
        self._templates[template.name][template.version] = template

    def list_templates(self) -> list[dict]:
        return [
            {
                "name": name,
                "versions": list(versions.keys()),
                "latest": sorted(versions.keys())[-1],
            }
            for name, versions in self._templates.items()
        ]
